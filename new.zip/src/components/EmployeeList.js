import React from 'react'

export const EmployeeList = () => {
  return (
    <div>EmployeeList</div>
  )
}
